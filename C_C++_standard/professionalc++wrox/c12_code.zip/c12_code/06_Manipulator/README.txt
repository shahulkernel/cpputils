Microsoft Visual C++ 2013 does not support std::quoted() yet.
g++ 4.9.0 and clang++ 3.4.1 don't support std::put_time() yet.