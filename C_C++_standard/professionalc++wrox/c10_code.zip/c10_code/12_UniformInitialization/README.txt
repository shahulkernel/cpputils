Microsoft Visual C++ 2013 does not yet support uniform initialization
of the mArray data member in MyClass.