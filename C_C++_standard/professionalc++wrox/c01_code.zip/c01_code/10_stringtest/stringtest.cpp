#include <string>
#include <iostream>

using namespace std;

int main()
{
	string myString = "Hello, World";

	cout << "The value of myString is " << myString << endl;

	return 0;
}
