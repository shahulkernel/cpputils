#include <vector>
using namespace std;

int main()
{
	vector<int> intVector1 = { 1, 2, 3, 4, 5, 6 };  // Uses C++11 uniform initialization
	vector<int> intVector2{ 1, 2, 3, 4, 5, 6 };
	return 0;
}
