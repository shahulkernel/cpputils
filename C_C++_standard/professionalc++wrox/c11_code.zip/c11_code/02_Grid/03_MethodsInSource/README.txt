Do not include Grid.cpp in your project.
