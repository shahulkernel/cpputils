Compile each of the source files in this directory separately.
