Compile each of the source files in this directory separately.

Visual C++ 2013 does not yet support noexcept used in WritingExceptions.cpp.

Notes:
CathingPolymorphicallyIncorrect.cpp may generate warnings when compiled.
