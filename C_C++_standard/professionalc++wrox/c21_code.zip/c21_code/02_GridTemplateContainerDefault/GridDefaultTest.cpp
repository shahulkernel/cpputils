#include "GridDefault.h"

#include <vector>
#include <deque>
#include <iostream>
using namespace std;

int main()
{
	Grid<int, deque<int>> myDequeGrid;
	Grid<int, vector<int>> myVectorGrid;
	Grid<int> myVectorGrid2;

	return 0;
}
