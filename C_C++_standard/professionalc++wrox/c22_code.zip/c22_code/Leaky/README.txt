Compile each of the source files in this directory separately.

"Leaky MS VC++.cpp" should be compiled with Microsoft Visual C++.
It contains memory leaks that will be detected by the Visual C++ debugger.

"Leaky.cpp" can be compiled on any platform.
It contains a memory leak which can be found using a tool like valgrind.
