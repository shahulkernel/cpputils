Compile AnotherFile.cpp and FirstFile.cpp together.
Compile StaticsInFunctions.cpp alone.
