Two source files in this directory include a main() function. Your project
should include SpreadsheetCell.cpp and either SpreadsheetCellTest.cpp or
SpreadsheetCellAssignCopy.cpp

