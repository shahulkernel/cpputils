This example compiles on all platforms, but the profiling was tested
only on Linux with the GCC 4.8 C++ Compiler and on Windows with
Visual C++ 2013.
Follow the instructions in Chapter 25 to profile the program.
