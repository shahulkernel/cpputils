Compile SpreadsheetCell.cpp + Pointer.h + PointerTest.cpp together and
compile SpreadsheetCell.cpp + PointerBool.h + PointerBoolTest.cpp together.
Notes: PointerBoolTest.cpp might generate some warnings when you compile it.
