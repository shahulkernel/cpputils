Compile each of the source files in this directory separately.

"Leaky MS VC++.cpp" should be compiled with Microsoft Visual C++.
"Leaky.cpp" can be compiled on any platform.
