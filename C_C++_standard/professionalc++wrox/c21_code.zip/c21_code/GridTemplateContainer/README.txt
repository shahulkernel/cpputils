Compile each of GridTest.cpp, GridDefaultTest.cpp, and
GridTemplateTemplateTest.cpp separately.
