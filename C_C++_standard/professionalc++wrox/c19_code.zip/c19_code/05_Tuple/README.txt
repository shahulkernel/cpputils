Compile each of the source files in this directory separately.

Microsoft Visual C++ 2013 does not yet support get<T>() where T is
a type instead of an index.