The subdirectories AccessControl and DeclarationOrder contain alternative
versions of the SpreadsheetCell.h header file. You can test these alternative
versions by modifying SpreadsheetCell.cpp and SpreadsheetCellTest.cpp to
include the header file from these subdirectories instead of the one in
this directory.

Note that when you use the version in AccessControl, the code doesn't compile.

