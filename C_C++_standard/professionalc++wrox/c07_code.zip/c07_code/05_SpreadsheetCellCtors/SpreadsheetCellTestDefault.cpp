#include "SpreadsheetCell.h"

int main()
{
  SpreadsheetCell myCell;
  myCell.setValue(6);

  return 0;
}
